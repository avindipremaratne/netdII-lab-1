﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lab1_inc
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            // Create a worker object for the calculation purposes
            PieceworkWorker worker = new PieceworkWorker(txtWorkerName.Text, txtMessagesSent.Text);
           
            //If condion to proceed and display the values if the worker exists
            if (worker.Pay > 0)
            {
                // Output the worker's pay values
                lblWorkerPayOutput.Content = worker.Pay.ToString("c");
                lblOverallTotalPayOutput.Content = PieceworkWorker.TotalPay.ToString("c");
                lblAveragePayOutput.Content = PieceworkWorker.AveragePay.ToString("c");
               
                // Disable input fields
                txtWorkerName.IsEnabled = false;
                txtMessagesSent.IsEnabled = false;               
                btnCalculate.IsEnabled = false;

                btnClear.Focus();
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtWorkerName.Clear();
            txtWorkerName.IsEnabled = true;
            txtMessagesSent.Clear();
            txtMessagesSent.IsEnabled = true;
            
            // Clear output fields
            lblWorkerPayOutput.Content = "";
            lblAveragePayOutput.Content = String.Empty;
            lblOverallTotalPayOutput.Content = String.Empty;

            // Re-enable the calculate button
            btnCalculate.IsEnabled = true;

            txtWorkerName.Focus();
        }
    }
}
